import mongoose from "mongoose";

const ingredientCategorySchema = new mongoose.Schema({
  ingredientCategory_name: {
    type: String,
    maxlength: [50, "Maximum 50 charcters are permitted"],
    minLength: [3, "ingredientCategory_name should have more than 3 character"],
    required: [true, "please enter ingredientCategory_name"],
    trim: true,
    default: null
  },
  description: {
     type: String,
    maxlength: [100, "Maximum 100 charcters are permitted"],
      trim: true,
    default: null
  },
  company_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Company",
    required: [true, "Please enter company_id"],
  },
  del_status: {
    type: String,
    enum: {
      values: ["Live", "Deleted"],
      message: "Value is not matched",
    },
    default: "Live",
  }
});
export const IngredientCategory = mongoose.model("IngredientCategory", ingredientCategorySchema);
