import { KitchenModel, KitchenEntity } from "@domain/kitchen/entities/kitchen";
import { KitchenRepository } from "@domain/kitchen/repositories/kitchen-repository";
import { KitchenDataSource } from "@data/kitchen/datasources/kitchen-data-source";
import { AdminEntity } from "@domain/admin/entities/admin";
import ApiError from "@presentation/error-handling/api-error";

export class KitchenRepositoryImpl implements KitchenRepository {
  private readonly dataSource: KitchenDataSource;

  constructor(dataSource: KitchenDataSource) {
    this.dataSource = dataSource;
  }

  async createKitchen(kitchen: KitchenModel): Promise<Either<ErrorClass, KitchenEntity>> {
  try {
    let i = await this.dataSource.create(kitchen);
    return Right<ErrorClass, KitchenEntity>(i);
  } catch (e) {
    if(e instanceof ApiError && e.name === "conflict"){
      return Left<ErrorClass, KitchenEntity>(ApiError.kitchen_codeExists());
    }
    return Left<ErrorClass, KitchenEntity>(ApiError.badRequest());
  }
  }

  async deleteKitchen(id: string): Promise<void> {
    await this.dataSource.delete(id);
  }

  async updateKitchen(id: string, data: KitchenModel): Promise<KitchenEntity> {
    return await this.dataSource.update(id, data);
  }

  async getKitchens(): Promise<KitchenEntity[]> {
    return await this.dataSource.getAllkitchens();
  }

  async getKitchenById(id: string): Promise<KitchenEntity | null> {
    return await this.dataSource.read(id);
  }
}