import { NextFunction, Request, Response } from "express";
import {
  KitchenModel,
  KitchenEntity,
  KitchenMapper,
} from "@domain/kitchen/entities/kitchen";
import { CreateKitchenUsecase } from "@domain/kitchen/usecases/create-kitchen";
import { DeleteKitchenUsecase } from "@domain/kitchen/usecases/delete-kitchen";
import { GetKitchenByIdUsecase } from "@domain/kitchen/usecases/get-kitchen-by-id";
import { UpdateKitchenUsecase } from "@domain/kitchen/usecases/update-kitchen";
import { GetAllKitchensUsecase } from "@domain/kitchen/usecases/get-all-kitchen";
import ApiError from "@presentation/error-handling/api-error";

export class KitchenService {
  private readonly CreateKitchenUsecase: CreateKitchenUsecase;
  private readonly DeleteKitchenUsecase: DeleteKitchenUsecase;
  private readonly GetKitchenByIdUsecase: GetKitchenByIdUsecase;
  private readonly UpdateKitchenUsecase: UpdateKitchenUsecase;
  private readonly GetAllKitchensUsecase: GetAllKitchensUsecase;

  constructor(
    CreateKitchenUsecase: CreateKitchenUsecase,
    DeleteKitchenUsecase: DeleteKitchenUsecase,
    GetKitchenByIdUsecase: GetKitchenByIdUsecase,
    UpdateKitchenUsecase: UpdateKitchenUsecase,
    GetAllKitchensUsecase: GetAllKitchensUsecase
  ) {
    this.CreateKitchenUsecase = CreateKitchenUsecase;
    this.DeleteKitchenUsecase = DeleteKitchenUsecase;
    this.GetKitchenByIdUsecase = GetKitchenByIdUsecase;
    this.UpdateKitchenUsecase = UpdateKitchenUsecase;
    this.GetAllKitchensUsecase = GetAllKitchensUsecase;
  }

  async createKitchen(req: Request, res: Response): Promise<void> {
  
      
      // Extract Kitchen data from the request body and convert it to KitchenModel
      const kitchenData: KitchenModel = KitchenMapper.toModel(req.body);

      // Call the CreateKitchenUsecase to create the kitchen
      const newKitchen: Either<ErrorClass, KitchenEntity> = await this.CreateKitchenUsecase.execute(
        kitchenData
      );

      newKitchen.cata(
        (error: ErrorClass) =>
        res.status(error.status).json({ error: error.message }),
(result: KitchenEntity) =>{
const responseData = KitchenMapper.toEntity(result, true);
return res.json(responseData)
}
      );

     
}
  

  async deleteKitchen(req: Request, res: Response): Promise<void> {
    try {
      const kitchenId: string = req.params.kitchenId;

      // Call the DeleteKitchenUsecase to delete the kitchen
      await this.DeleteKitchenUsecase.execute(kitchenId);

      // Send a success message as a JSON response
      res.json({ message: "Kitchen deleted successfully." });
    } catch (error) {
      if(error instanceof ApiError){
        res.status(error.status).json({ error: error.message });
       }
          ApiError.internalError()
    }
  }

  async getKitchenById(req: Request, res: Response): Promise<void> {
    try {
      const kitchenId: string = req.params.kitchenId;

      // Call the GetKitchenByIdUsecase to get the kitchen by ID
      const kitchen: KitchenEntity | null = await this.GetKitchenByIdUsecase.execute(
        kitchenId
      );

      if (kitchen) {
        // Convert Kitchen from KitchenEntity to plain JSON object using KitchenMapper
        const responseData = KitchenMapper.toModel(kitchen);

        // Send the kitchen as a JSON response
        res.json(responseData);
      } else {
        // Send a not found message as a JSON response
        ApiError.notFound()
      }
    } catch (error) {
      if(error instanceof ApiError){
        res.status(error.status).json({ error: error.message });
       }
          ApiError.internalError()
       
    }
  }

  async updateKitchen(req: Request, res: Response): Promise<void> {
    try {
      const kitchenId: string = req.params.kitchenId;
      const kitchenData: KitchenModel = req.body;

      // Get the existing kitchen by ID
      const existingKitchen: KitchenEntity | null =
        await this.GetKitchenByIdUsecase.execute(kitchenId);

      if (!existingKitchen) {
        // If Kitchen is not found, send a not found message as a JSON response
        ApiError.notFound();
        return;
      }

      // Convert kitchenData from KitchenModel to KitchenEntity using KitchenMapper
      const updatedKitchenEntity: KitchenEntity = KitchenMapper.toEntity(
        kitchenData,
        true,
        existingKitchen
      );

      // Call the UpdateKitchenUsecase to update the kitchen
      const updatedKitchen: KitchenEntity = await this.UpdateKitchenUsecase.execute(
        kitchenId,
        updatedKitchenEntity
      );

      // Convert updatedKitchen from KitchenEntity to plain JSON object using KitchenMapper
      const responseData = KitchenMapper.toModel(updatedKitchen);

      // Send the updated kitchen as a JSON response
      res.json(responseData);
    } catch (error) {

      console.log(error);
      if(error instanceof ApiError){
        res.status(error.status).json({ error: error.message });
       }
          ApiError.internalError()
    }
  }

  async getAllKitchens(req: Request, res: Response, next:NextFunction): Promise<void> {
    try {
      // Call the GetAllKitchensUsecase to get all kitchens
      const kitchens: KitchenEntity[] = await this.GetAllKitchensUsecase.execute();

      // Convert Kitchens from an array of KitchenEntity to an array of plain JSON objects using kitchenMapper
      const responseData = kitchens.map((kitchen) => KitchenMapper.toModel(kitchen));

      // Send the kitchens as a JSON response
      res.json(responseData);
    } catch (error) {
      if(error instanceof ApiError){
        res.status(error.status).json({ error: error.message });
       }
          ApiError.internalError()
    }
  }
}
