import { CreateCompany } from "./create-company";
import { DeleteCompany } from "./delete-company";

module.exports = {
  CreateCompany,
  DeleteCompany,
};
