import { type KitchenRepository } from "@domain/kitchen/repositories/kitchen-repository";
export interface DeleteKitchenUsecase {
  execute: (kitchenId: string) => Promise<void>
}

export class DeleteKitchen implements DeleteKitchenUsecase {
  private readonly kitchenRepository: KitchenRepository;

  constructor(kitchenRepository: KitchenRepository) {
    this.kitchenRepository = kitchenRepository;
  }

  async execute(kitchenId: string): Promise<void> {
    await this.kitchenRepository.deleteKitchen(kitchenId);
  }
}
