import { KitchenEntity, KitchenModel } from "@domain/kitchen/entities/kitchen";
import { KitchenRepository } from "@domain/kitchen/repositories/kitchen-repository";

export interface UpdateKitchenUsecase {
  execute: (
    kitchenId: string,
    kitchenData: Partial<KitchenModel>
  ) => Promise<KitchenEntity>;
}

export class UpdateKitchen implements UpdateKitchenUsecase {
  private readonly kitchenRepository: KitchenRepository;

  constructor(kitchenRepository: KitchenRepository) {
    this.kitchenRepository = kitchenRepository;
  }

  // async execute(kitchenId: string, kitchenData: KitchenModel): Promise<KitchenEntity> {
  //   return await this.kitchenRepository.updateKitchen(kitchenId, kitchenData);
  // }
  // UpdateKitchenUsecase
  async execute(
    kitchenId: string,
    kitchenData: Partial<KitchenModel>
  ): Promise<KitchenEntity> {
    const existingKitchen: KitchenEntity | null =
      await this.kitchenRepository.getKitchenById(kitchenId);

    if (!existingKitchen) {
      throw new Error("Kitchen not found.");
    }

    // Perform the partial update by merging kitchenData with existingKitchen
    const updatedKitchenData: KitchenModel = {
      ...existingKitchen,
      ...kitchenData,
    };

    // Save the updatedKitchenData to the repository
    await this.kitchenRepository.updateKitchen(kitchenId, updatedKitchenData);

    // Fetch the updated admin entity from the repository
    const updatedKitchenEntity: KitchenEntity | null =
      await this.kitchenRepository.getKitchenById(kitchenId);

    if (!updatedKitchenEntity) {
      throw new Error("Kitchen not found after update.");
    }

    return updatedKitchenEntity;
  }
}
