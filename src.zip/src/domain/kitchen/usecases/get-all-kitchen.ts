import { KitchenEntity } from "@domain/kitchen/entities/kitchen";
import { KitchenRepository } from "@domain/kitchen/repositories/kitchen-repository";

export interface GetAllKitchensUsecase {
  execute: () => Promise<KitchenEntity[]>;
}

export class GetAllKitchens implements GetAllKitchensUsecase {
  private readonly kitchenRepository: KitchenRepository;

  constructor(kitchenRepository: KitchenRepository) {
    this.kitchenRepository = kitchenRepository;
  }

  async execute(): Promise<KitchenEntity[]> {
    return await this.kitchenRepository.getKitchens();
  }
}
