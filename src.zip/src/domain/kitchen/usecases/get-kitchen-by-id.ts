import { KitchenEntity } from "@domain/kitchen/entities/kitchen";
import { KitchenRepository } from "@domain/kitchen/repositories/kitchen-repository";

export interface GetKitchenByIdUsecase {
  execute: (kitchenId: string) => Promise<KitchenEntity | null>;
}

export class GetKitchenById implements GetKitchenByIdUsecase {
  private readonly kitchenRepository:KitchenRepository;

  constructor(kitchenRepository: KitchenRepository) {
    this.kitchenRepository = kitchenRepository;
  }

  async execute(kitchenId: string): Promise<KitchenEntity | null> {
    return await this.kitchenRepository.getKitchenById(kitchenId);
  }
}