import {KitchenModel,KitchenEntity } from "@domain/kitchen/entities/kitchen";
import { Either } from "monet";
import { ErrorClass } from "@presentation/error-handling/api-error";

export interface KitchenRepository {
  createKitchen(kitchen: KitchenModel): Promise<Either<ErrorClass, KitchenEntity>>;
  deleteKitchen(id: string): Promise<void>;
  updateKitchen(id: string, data: KitchenModel): Promise<KitchenEntity>;
  getKitchens(): Promise<KitchenEntity[]>;
  getKitchenById(id: string): Promise<KitchenEntity | null>;
}